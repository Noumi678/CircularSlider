import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: CircularSliderPage(),
    );
  }
}

class CircularSliderPage extends StatefulWidget {
  @override
  _CircularSliderPageState createState() => _CircularSliderPageState();
}

class _CircularSliderPageState extends State<CircularSliderPage> {
  double htmlValue = 0.5;
  double cssValue = 0.5;
  double jsValue = 0.5;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Circular Sliders'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            CircularSlider(
              value: htmlValue,
              onChanged: (value) {
                setState(() {
                  htmlValue = value;
                });
              },
              label: 'HTML',
            ),
            CircularSlider(
              value: cssValue,
              onChanged: (value) {
                setState(() {
                  cssValue = value;
                });
              },
              label: 'CSS',
            ),
            CircularSlider(
              value: jsValue,
              onChanged: (value) {
                setState(() {
                  jsValue = value;
                });
              },
              label: 'JavaScript',
            ),
          ],
        ),
      ),
    );
  }
}

class CircularSlider extends StatefulWidget {
  final double value;
  final ValueChanged<double>? onChanged;
  final String label;

  const CircularSlider({
    Key? key,
    required this.value,
    required this.label,
    this.onChanged,
  }) : super(key: key);

  @override
  _CircularSliderState createState() => _CircularSliderState();
}

class _CircularSliderState extends State<CircularSlider> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: Duration(milliseconds: 200), vsync: this);
    _animation = Tween<double>(begin: widget.value, end: widget.value).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant CircularSlider oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value) {
      _controller.reset();
      _controller.animateTo(widget.value, duration: Duration(milliseconds: 200), curve: Curves.easeInOut);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          widget.label,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 10),
        Container(
          width: 200.0,
          height: 200.0,
          child: Stack(
            children: [
              Center(
                child: Container(
                  width: 160.0,
                  height: 160.0,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.grey, width: 4.0),
                  ),
                ),
              ),
              Positioned(
                top: 100.0,
                left: 100.0,
                child: Transform.rotate(
                  angle: -3.14 / 2,
                  child: GestureDetector(
                    onPanUpdate: (details) {
                      if (widget.onChanged != null) {
                        double angle = details.localPosition.direction;
                        double newValue = angle / (2 * 3.14);
                        widget.onChanged!(newValue);
                        _controller.value = newValue;
                      }
                    },
                    child: AnimatedBuilder(
                      animation: _animation,
                      builder: (context, _) {
                        return CustomPaint(
                          painter: CirclePainter(_animation.value),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class CirclePainter extends CustomPainter {
  final double value;

  CirclePainter(this.value);

  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..strokeWidth = 8.0
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    // Define gradient colors
    List<Color> gradientColors = [
      Colors.blue.withOpacity(0.5),
      Colors.blue,
    ];

    // Create a SweepGradient
    Gradient gradient = SweepGradient(
      colors: gradientColors,
      stops: [0.0, 1.0],
    );

    paint.shader = gradient.createShader(Rect.fromCircle(center: Offset(size.width / 2, size.height / 2), radius: size.width / 2));

    double startAngle = -3.14 / 2;
    double sweepAngle = value * 2 * 3.14;

    canvas.drawArc(
      Rect.fromCircle(center: Offset(size.width / 2, size.height / 2), radius: size.width / 2),
      startAngle,
      sweepAngle,
      false,
      paint,
    );
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
